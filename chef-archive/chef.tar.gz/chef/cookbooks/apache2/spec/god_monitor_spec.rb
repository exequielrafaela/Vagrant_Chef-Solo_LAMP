require 'spec_helper'

supported_platforms

describe 'apache2::god_monitor' do
end
