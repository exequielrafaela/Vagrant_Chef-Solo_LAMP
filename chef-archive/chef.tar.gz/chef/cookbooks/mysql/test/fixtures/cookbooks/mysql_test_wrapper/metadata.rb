name 'mysql_test_wrapper'
version '0.0.1'

depends 'mysql'
